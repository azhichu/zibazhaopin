-- jobs.sql

-- 创建 jobs 表
CREATE TABLE IF NOT EXISTS `jobs` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `company` VARCHAR(255) NOT NULL,
    `position` VARCHAR(255) NOT NULL,
    `address` VARCHAR(255) NOT NULL,
    `salary` VARCHAR(100) NOT NULL,
    `description` TEXT NOT NULL,
    `requirements` TEXT NOT NULL,
    `company_logo` VARCHAR(255) DEFAULT 'images/company_logos/default_logo.png',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 插入示例数据
INSERT INTO `jobs` (`company`, `position`, `address`, `salary`, `description`, `requirements`, `company_logo`) VALUES
('腾讯', '软件工程师', '深圳', '20k-30k', '负责开发和维护公司核心产品', '熟悉Java、Python等编程语言', 'images/company_logos/tencent.png'),
('阿里巴巴', '产品经理', '杭州', '25k-35k', '负责产品规划和管理', '有3年以上产品管理经验', 'images/company_logos/alibaba.png'),
('百度', '数据分析师', '北京', '18k-28k', '负责数据分析和报告生成', '熟悉SQL、Python等工具', 'images/company_logos/baidu.png');