<?php
// config/database.php

// 引入配置
require_once __DIR__ . '/config.php';

// 数据库连接参数
$host = 'localhost';
$db   = '账号';
$user = '账号';
$pass = '密码';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // 抛出异常
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // 默认返回关联数组
    PDO::ATTR_EMULATE_PREPARES   => false,                  // 禁用模拟预处理
];

try {
    // 实例化 PDO
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    // 抛出异常以便上层捕获
    throw new PDOException($e->getMessage(), (int)$e->getCode());
}
?>