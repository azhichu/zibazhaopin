<?php
// config/config.php

define('BASE_URL', 'https://max.gzbxjsg.cn/');
?>