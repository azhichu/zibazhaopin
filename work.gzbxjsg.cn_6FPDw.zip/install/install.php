<?php
// install/install.php

session_start();

// 检查是否已安装
if (file_exists('installed.txt')) {
    echo "项目已经安装。如果您需要重新安装，请删除 'installed.txt' 文件。";
    exit();
}

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 收集并验证输入
    $db_host = trim($_POST['db_host']);
    $db_name = trim($_POST['db_name']);
    $db_user = trim($_POST['db_user']);
    $db_pass = $_POST['db_pass'];
    $admin_username = trim($_POST['admin_username']);
    $admin_password = $_POST['admin_password'];
    $admin_email = trim($_POST['admin_email']);

    // 基本验证
    $errors = [];
    if (empty($db_host) || empty($db_name) || empty($db_user)) {
        $errors[] = "请填写所有数据库信息。";
    }
    if (empty($admin_username) || empty($admin_password) || empty($admin_email)) {
        $errors[] = "请填写所有管理员信息。";
    }

    if (!empty($errors)) {
        echo "<ul>";
        foreach ($errors as $error) {
            echo "<li style='color:red;'>$error</li>";
        }
        echo "</ul>";
    } else {
        // 连接数据库
        try {
            $dsn = "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4";
            $pdo = new PDO($dsn, $db_user, $db_pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            echo "数据库连接成功！<br>";
        } catch (PDOException $e) {
            die("数据库连接失败：".$e->getMessage());
        }

        // 创建数据库表
        try {
            $sql = file_get_contents('database/jobs.sql');
            $pdo->exec($sql);
            echo "数据库表创建成功！<br>";
        } catch (PDOException $e) {
            die("创建表失败：".$e->getMessage());
        }

        // 插入管理员账户
        try {
            $hashed_password = md5($admin_password);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)");
            $stmt->execute([$admin_username, $hashed_password, $admin_email, 'admin']);
            echo "管理员账户创建成功！<br>";
        } catch (PDOException $e) {
            die("插入管理员账户失败：".$e->getMessage());
        }

        // 生成 installed.txt 文件
        file_put_contents('installed.txt', '已安装');
        echo "安装成功！<br>";
        echo "<a href='../index.php'>点击进入网站首页</a>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>安装</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="install-container">
        <h2>安装向导</h2>
        <form method="post">
            <h3>数据库信息</h3>
            <label for="db_host">主机：</label>
            <input type="text" id="db_host" name="db_host" required>
            <label for="db_name">数据库名：</label>
            <input type="text" id="db_name" name="db_name" required>
            <label for="db_user">用户名：</label>
            <input type="text" id="db_user" name="db_user" required>
            <label for="db_pass">密码：</label>
            <input type="password" id="db_pass" name="db_pass">
            <h3>管理员账户</h3>
            <label for="admin_username">用户名：</label>
            <input type="text" id="admin_username" name="admin_username" required>
            <label for="admin_password">密码：</label>
            <input type="password" id="admin_password" name="admin_password" required>
            <label for="admin_email">邮箱：</label>
            <input type="email" id="admin_email" name="admin_email" required>
            <button type="submit">安装</button>
        </form>
    </div>
</body>
</html>