<?php
// company_list.php

// 引入数据库配置和根URL
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

// 获取分类ID（假设通过URL参数传递）
if (isset($_GET['category_id'])) {
    $category_id = intval($_GET['category_id']);
    if ($category_id <= 0) {
        die("无效的分类ID。");
    }
} else {
    die("分类ID未指定。");
}

// 获取公司数据
try {
    $stmt = $pdo->prepare("SELECT * FROM companies WHERE category_id = ?");
    $stmt->execute([$category_id]);
    $companies = $stmt->fetchAll();
} catch (PDOException $e) {
    die("数据库错误：" . htmlspecialchars($e->getMessage()));
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>公司列表</title>
    <!-- 引入 Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 图标库 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- 自定义 PC 端 CSS -->
    <link rel="stylesheet" href="../css/style_pc_company_list.css">
    <!-- 网站图标 -->
    <link rel="icon" href="https://max.gzbxjsg.cn/static/images/logo.png" type="image/png">
    <style>
        /* 自定义样式 */
        body {
            background-color: #f8f9fa;
            font-family: 'Roboto', sans-serif;
        }
        .header {
            background-color: #ffffff;
            padding: 20px 0;
            border-bottom: 1px solid #dee2e6;
            margin-bottom: 30px;
        }
        .header h1 {
            font-size: 2rem;
            color: #343a40;
        }
        .company-card {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            border: 1px solid #dee2e6;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .company-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        .company-card .logo img {
            max-height: 100px;
            max-width: 100%;
            border-radius: 10px;
        }
        .company-card h4 {
            font-size: 1.5rem;
            color: #343a40;
            margin-bottom: 10px;
        }
        .company-card p {
            font-size: 1rem;
            color: #555555;
        }
        .company-card a {
            width: 100%;
        }
        .footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 20px 0;
            margin-top: 40px;
        }
        .footer a {
            color: #ffffff;
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="container d-flex justify-content-between align-items-center">
            <h1>公司列表</h1>
            <div class="search-bar position-relative">
                <input type="text" id="searchInput" class="form-control" placeholder="搜索公司...">
                <i class="fas fa-search position-absolute top-50 end-0 translate-middle-y me-2" style="cursor: pointer;" onclick="search()"></i>
            </div>
        </div>
    </div>

    <div class="container my-4">
        <div class="row">
            <?php foreach ($companies as $company): ?>
                <div class="col-md-4 col-sm-6 mb-4">
                    <div class="company-card d-flex flex-column justify-content-between">
                        <div class="text-center">
                            <?php
                                $logoPath = $company['logo'];
                                if (strpos($logoPath, 'http') !== 0) {
                                    $logoPath = BASE_URL . $logoPath;
                                }
                            ?>
                            <img src="<?php echo $logoPath; ?>" alt="<?php echo htmlspecialchars($company['name']); ?>" class="logo img-fluid mb-3">
                            <h4><?php echo htmlspecialchars($company['name']); ?></h4>
                            <p><?php echo htmlspecialchars($company['address']); ?></p>
                        </div>
                        <a href="company_detail.php?id=<?php echo $company['id']; ?>" class="btn btn-primary mt-3">查看详情</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <footer class="footer">
        <div class="container text-center">
            <a href="https://t.me/manbojt" target="_blank" class="text-white me-3">
                <i class="fab fa-telegram fa-lg me-2"></i>联系我们
            </a>
        </div>
    </footer>

    <!-- 引入 Bootstrap 5 JS Bundle (包含 Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    <!-- 自定义 PC 端 JS -->
    <script src="../js/script_pc_company_list.js" defer></script>
</body>
</html>