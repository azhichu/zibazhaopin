<?php
// pc/index.php

// 检测是否安装
if (!file_exists('../install/installed.txt')) {
    header('Location: ../install/install.php');
    exit();
}

// 引入数据库配置和根URL
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

try {
    $stmt = $pdo->query("SELECT * FROM categories");
    $categories = $stmt->fetchAll();
} catch (PDOException $e) {
    die("数据库错误：" . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>招聘信息 - PC端</title>
    <!-- 引入 Bootstrap 5 CSS（PC优化版本） -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 图标库 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- 自定义 PC 端 CSS -->
    <link rel="stylesheet" href="../css/style_pc.css">
    <!-- 网站图标 -->
    <link rel="icon" href="<?php echo BASE_URL; ?>logo/i.png" type="image/png">
    <!-- Google Fonts（可选，用于更好的字体） -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        /* 自定义样式 */
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fa;
        }
        .header {
            background-color: #343a40;
            color: #ffffff;
            padding: 20px 0;
            margin-bottom: 40px;
        }
        .header .logo img {
            width: 60px;
            height: 60px;
        }
        .header .logo h2 {
            font-size: 2rem;
            margin-left: 20px;
        }
        .search-bar {
            max-width: 400px;
            margin: 0 auto;
        }
        .search-bar input {
            border-radius: 20px;
            padding: 10px 20px;
            font-size: 1.2rem;
        }
        .search-bar i {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
        }
        .categories-container {
            flex: 1;
            padding: 0 15px;
        }
        .category-card {
            padding: 20px;
            border-radius: 10px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            background-color: #ffffff;
            margin-bottom: 30px;
        }
        .category-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        .category-card h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: #343a40;
        }
        .category-card p {
            font-size: 1rem;
            color: #555555;
        }
        .category-card a {
            width: 100%;
        }
        footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 20px 0;
        }
        footer a {
            color: #ffffff;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }
        /* 使 footer 固定在底部 */
        .content {
            flex: 1;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="logo d-flex align-items-center">
                <img src="<?php echo BASE_URL; ?>static/images/logo.png" alt="Logo">
                <h2 class="mb-0 ms-3">招聘信息</h2>
            </div>
            <div class="search-bar position-relative">
                <input type="text" id="searchInput" class="form-control" placeholder="搜索职位...">
                <i class="fas fa-search position-absolute top-50 end-0 translate-middle-y me-2" style="cursor: pointer; color: #6c757d;" onclick="search()"></i>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="container my-4">
            <main>
                <div class="categories-container row">
                    <?php foreach ($categories as $category): ?>
                        <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
                            <div class="category-card d-flex flex-column justify-content-between">
                                <div>
                                    <h3 class="text-primary"><?php echo htmlspecialchars($category['name']); ?></h3>
                                    <p><?php echo $category['description']; ?></p>
                                </div>
                                <a href="company_list.php?category_id=<?php echo $category['id']; ?>" class="btn btn-primary mt-3">查看公司</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </main>
        </div>
    </div>

    <footer class="bg-primary text-white text-center">
        <div class="container">
            <a href="https://t.me/manbojt" target="_blank" class="text-white me-3 text-decoration-none" style="display: flex; align-items: center; justify-content: center;">
                <i class="fab fa-telegram fa-lg me-2"></i>
                <span>联系我们</span>
            </a>
        </div>
    </footer>

    <!-- Bootstrap 5 JS Bundle (包含 Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    <!-- 自定义 PC 端 JS -->
    <script src="../js/script_pc.js" defer></script>
</body>
</html>