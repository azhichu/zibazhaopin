<?php
// company_detail.php

// 获取公司ID
if (isset($_GET['id'])) {
    $company_id = intval($_GET['id']);
    if ($company_id <= 0) {
        // 如果 company_id 无效，则重定向到 index.php
        header('Location: index.php');
        exit();
    }
} else {
    // 如果没有提供 company_id，则重定向到 index.php
    header('Location: index.php');
    exit();
}

// 获取公司数据
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

try {
    // 使用预处理语句防止 SQL 注入
    $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = ?");
    $stmt->execute([$company_id]);
    $company = $stmt->fetch();

    if (!$company) {
        // 如果没有找到相关公司，则重定向到公司列表或显示错误消息
        header('Location: company_list.php');
        exit();
    }
} catch (PDOException $e) {
    die("数据库错误：" . htmlspecialchars($e->getMessage()));
}

// 获取公司相关的职位（可选）
try {
    $stmt = $pdo->prepare("SELECT * FROM jobs WHERE company_id = ?");
    $stmt->execute([$company_id]);
    $jobs = $stmt->fetchAll();
} catch (PDOException $e) {
    $jobs = [];
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($company['name']); ?> - 公司详情</title>
    <!-- 引入 Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 图标库 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- 自定义 PC 端 CSS -->
    <link rel="stylesheet" href="css/style_pc_company.css">
    <!-- 网站图标 -->
    <link rel="icon" href="https://max.gzbxjsg.cn/static/images/logo.png" type="image/png">
    <!-- Google Fonts（可选，用于更好的字体） -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        /* 自定义样式 */
        body {
            background-color: #f8f9fa;
            font-family: 'Roboto', sans-serif;
        }
        .header {
            background-color: #ffffff;
            padding: 20px 0;
            border-bottom: 1px solid #dee2e6;
            margin-bottom: 30px;
        }
        .header .logo img {
            width: 60px;
            height: 60px;
        }
        .search-bar {
            max-width: 400px;
            margin: 0 auto;
            position: relative;
        }
        .search-bar input {
            border-radius: 20px;
            padding: 10px 20px;
            font-size: 1.2rem;
        }
        .search-bar i {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
        }
        .company-detail {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .company-logo {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .company-info p {
            font-size: 1.1rem;
            color: #555555;
        }
        .jobs-container .job-card {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            border: 1px solid #dee2e6;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .jobs-container .job-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 20px 0;
            margin-top: 40px;
        }
        footer a {
            color: #ffffff;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="logo">
                <a href="index.php">
                    <img src="https://max.gzbxjsg.cn/static/images/logo.png" alt="Logo">
                </a>
            </div>
            <div class="search-bar position-relative">
                <input type="text" id="searchInput" class="form-control" placeholder="搜索职位...">
                <i class="fas fa-search position-absolute top-50 end-0 translate-middle-y me-2" style="cursor: pointer;" onclick="search()"></i>
            </div>
        </div>
    </div>

    <div class="container my-4">
        <main>
            <div class="company-detail">
                <h2 class="mb-4"><?php echo htmlspecialchars($company['name']); ?></h2>
                <div class="company-info mb-4 d-flex align-items-center">
                    <img src="<?php echo BASE_URL . htmlspecialchars($company['logo']); ?>" alt="<?php echo htmlspecialchars($company['name']); ?> Logo" class="company-logo me-4" width="150">
                    <div>
                        <p><strong>地址：</strong> <?php echo htmlspecialchars($company['address']); ?></p>
                        <!-- 可根据需要添加更多公司信息 -->
                    </div>
                </div>
                <h4>职位列表：</h4>
                <?php if (!empty($jobs)): ?>
                    <div class="jobs-container mt-3">
                        <?php foreach ($jobs as $job): ?>
                            <div class="job-card mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <a href="job_detail.php?job_id=<?php echo $job['id']; ?>" class="btn btn-primary">查看详情</a>
                                </div>
                                <h5 class="mt-3"><?php echo htmlspecialchars($job['position']); ?></h5>
                                <p><strong>薪资：</strong> <?php echo htmlspecialchars($job['salary']); ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info mt-3" role="alert">
                        <p>当前公司暂无职位信息。</p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <footer>
        <div class="container text-center">
            <a href="https://t.me/manbojt" target="_blank" class="text-white me-3">
                <i class="fab fa-telegram fa-lg me-2"></i>联系我们
            </a>
        </div>
    </footer>

    <!-- 引入 Bootstrap 5 JS Bundle (包含 Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    <!-- 自定义 PC 端 JS -->
    <script src="js/script_pc_company.js" defer></script>
</body>
</html>