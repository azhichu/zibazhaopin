// js/script_mobile_job_detail.js

document.addEventListener('DOMContentLoaded', function() {
    // 搜索功能
    function search() {
        const query = document.getElementById('searchInput').value.trim();
        if (query !== '') {
            // 重定向到搜索结果页面
            window.location.href = 'search_results.php?q=' + encodeURIComponent(query);
        }
    }

    // 点击搜索图标触发搜索
    const searchIcon = document.querySelector('.search-bar i');
    if (searchIcon) {
        searchIcon.addEventListener('click', search);
    }

    // 按下回车键触发搜索
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                search();
            }
        });
    }
});