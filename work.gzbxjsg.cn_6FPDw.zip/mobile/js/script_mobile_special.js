// jss/script_mobile_special.js

// 处理搜索输入
function search() {
    var query = document.getElementById('searchInput').value.trim();
    if (query !== '') {
        window.location.href = '../search.php?query=' + encodeURIComponent(query);
    }
}

// 处理导航栏滚动时固定
window.addEventListener('scroll', function() {
    var header = document.querySelector('header');
    if (window.scrollY > 50) {
        header.classList.add('fixed-top');
    } else {
        header.classList.remove('fixed-top');
    }
});