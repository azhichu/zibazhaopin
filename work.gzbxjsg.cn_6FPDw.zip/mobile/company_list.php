<?php
// company_list.php

// 引入数据库配置和根URL
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

// 获取分类ID（假设通过URL参数传递）
if (isset($_GET['category_id'])) {
    $category_id = intval($_GET['category_id']);
} else {
    die("分类ID未指定。");
}

// 获取公司数据
try {
    $stmt = $pdo->prepare("SELECT * FROM companies WHERE category_id = ?");
    $stmt->execute([$category_id]);
    $companies = $stmt->fetchAll();
} catch (PDOException $e) {
    die("数据库错误：" . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>公司列表</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 图标库 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- 自定义 CSS -->
    <link rel="stylesheet" href="../css/style_special.css">
</head>
<body>
    <div class="container my-4">
        <h1>公司列表</h1>
        <div class="row">
            <?php foreach ($companies as $company): ?>
                <div class="col-md-4 col-sm-6 mb-4">
                    <div class="company-card bg-light p-3 h-100 d-flex flex-column justify-content-between rounded-3 shadow-sm">
                        <div class="text-center">
                            <?php
                                $logoPath = $company['logo'];
                                if (strpos($logoPath, 'http') !== 0) {
                                    $logoPath = BASE_URL . $logoPath;
                                }
                            ?>
                            <img src="<?php echo $logoPath; ?>" alt="<?php echo htmlspecialchars($company['name']); ?>" class="img-fluid mb-3" style="max-height: 100px;">
                            <h4><?php echo htmlspecialchars($company['name']); ?></h4>
                            <p><?php echo htmlspecialchars($company['address']); ?></p>
                        </div>
                        <a href="company_detail.php?id=<?php echo $company['id']; ?>" class="btn btn-primary mt-3">查看详情</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>