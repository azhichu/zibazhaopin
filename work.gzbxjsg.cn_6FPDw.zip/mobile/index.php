<?php
// mobile/index.php

// 检测是否安装
if (!file_exists('../install/installed.txt')) {
    header('Location: ../install/install.php');
    exit();
}

// 引入数据库配置和根URL
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

try {
    $stmt = $pdo->query("SELECT * FROM categories");
    $categories = $stmt->fetchAll();
} catch (PDOException $e) {
    die("数据库错误：" . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>招聘信息 - 移动端</title>
    <!-- Bootstrap 5 CSS（移动优化版本） -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 图标库 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- 自定义移动端 CSS -->
    <link rel="stylesheet" href="../css/style_mobile_special.css">
    <!-- 网站图标 -->
    <link rel="icon" href="<?php echo BASE_URL; ?>logo/i.png" type="image/png">
    <!-- Google Fonts（可选，用于更好的字体） -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        /* 自定义样式 */

        /* 顶部导航栏 */
        .navbar-custom {
            background-color: rgba(0, 123, 255, 0.9); /* 半透明蓝色背景 */
            padding: 10px 0;
            transition: background-color 0.3s ease;
        }

        .navbar-custom.scrolled {
            background-color: rgba(0, 123, 255, 1); /* 滚动后完全不透明 */
        }

        .navbar-custom .logo img {
            width: 40px;
            height: 40px;
        }

        .navbar-custom .search-bar input {
            border-radius: 20px;
            padding: 8px 15px;
            font-size: 1rem;
            border: none;
        }

        .navbar-custom .search-bar i {
            color: #ffffff;
            cursor: pointer;
        }

        /* 主体内容 */
        .categories-container .category-card {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .categories-container .category-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 12px rgba(0,0,0,0.2);
        }

        .categories-container .category-card h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
        }

        .categories-container .category-card p {
            font-size: 1rem;
            color: #555555;
        }

        /* 页脚 */
        footer {
            background-color: rgba(0, 123, 255, 0.9);
            padding: 15px 0;
        }

        footer a {
            color: #ffffff;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }

        /* 响应式图片 */
        .category-card img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            margin-bottom: 15px;
        }

        /* 增加顶部间距 */
        .container.my-4.mt-5 {
            margin-top: 80px; /* 根据需要调整 */
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <header class="navbar-custom fixed-top">
            <div class="container d-flex justify-content-between align-items-center">
                <div class="logo d-flex align-items-center">
                    <img src="<?php echo BASE_URL; ?>static/images/logo.png" alt="Logo" class="me-2">
                    <h2 class="mb-0 text-white">招聘信息</h2>
                </div>
                <div class="search-bar position-relative">
                    <input type="text" id="searchInput" class="form-control" placeholder="搜索职位...">
                    <i class="fas fa-search position-absolute top-50 end-0 translate-middle-y me-2" style="cursor: pointer;" onclick="search()"></i>
                </div>
            </div>
        </header>
    </div>

    <div class="container my-4 mt-5" style="padding-bottom: 80px;"> <!-- 增加底部填充以防内容被固定底部遮挡 -->
        <main>
            <div class="categories-container row">
                <?php foreach ($categories as $category): ?>
                    <div class="col-12 mb-4">
                        <div class="category-card d-flex flex-column justify-content-between">
                            <div>
                                <h3 class="text-primary"><?php echo htmlspecialchars($category['name']); ?></h3>
                                <p><?php echo htmlspecialchars($category['description']); ?></p>
                            </div>
                            <a href="company_list.php?category_id=<?php echo $category['id']; ?>" class="btn btn-primary mt-3">查看公司</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </main>
    </div>

    <!-- Bootstrap 5 JS Bundle (包含 Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    <!-- 自定义移动端 JS -->
    <script src="../jss/script_mobile_special.js" defer></script>
</body>
</html>