<?php
// mobile/job_detail.php

// 获取职位ID
if (isset($_GET['job_id'])) {
    $job_id = intval($_GET['job_id']);
    if ($job_id <= 0) {
        // 如果 job_id 无效，则重定向到职位列表
        header('Location: job_list.php');
        exit();
    }
} else {
    // 如果没有提供 job_id，则重定向到职位列表
    header('Location: job_list.php');
    exit();
}

// 获取职位数据
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

try {
    // 使用预处理语句防止 SQL 注入
    $stmt = $pdo->prepare("SELECT * FROM jobs WHERE id = ?");
    $stmt->execute([$job_id]);
    $job = $stmt->fetch();

    if (!$job) {
        // 如果没有找到相关职位，则重定向到职位列表或显示错误消息
        header('Location: job_list.php');
        exit();
    }

    // 获取公司数据
    $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = ?");
    $stmt->execute([$job['company_id']]);
    $company = $stmt->fetch();

    if (!$company) {
        // 如果没有找到相关公司，可以选择处理
        $company = null;
    }
} catch (PDOException $e) {
    die("数据库错误：" . htmlspecialchars($e->getMessage()));
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($job['position']); ?> - 职位详情</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 图标库 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- 自定义移动端 CSS -->
    <link rel="stylesheet" href="../css/style_mobile_job_detail.css">
    <!-- 网站图标 -->
    <link rel="icon" href="<?php echo BASE_URL; ?>images/logo.png" type="image/png">
    <!-- Google Fonts（可选，用于更好的字体） -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        /* 自定义样式 */
        body {
            background-color: #f8f9fa;
            font-family: 'Roboto', sans-serif;
        }
        .header {
            background-color: #ffffff;
            padding: 10px 0;
            border-bottom: 1px solid #dee2e6;
            margin-bottom: 20px;
        }
        .logo {
            /* 移除网站 Logo */
            display: none;
        }
        .search-bar {
            max-width: 100%;
            margin: 0 auto;
            position: relative;
        }
        .search-bar input {
            border-radius: 20px;
            padding: 8px 15px;
            font-size: 1rem;
        }
        .search-bar i {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
        }
        .job-detail-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .company-logo {
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 15px;
        }
        .company-info p {
            font-size: 1rem;
            color: #555555;
            margin-bottom: 5px;
        }
        .job-description, .job-requirements, .job-salary {
            margin-bottom: 15px;
        }
        .job-description h4, .job-requirements h4, .job-salary h4 {
            color: #343a40;
            margin-bottom: 10px;
        }
        .job-description p, .job-requirements p, .job-salary p {
            font-size: 1rem;
            color: #555555;
        }
        footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 15px 0;
            margin-top: 30px;
        }
        footer a {
            color: #ffffff;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container my-4">
        <header class="header d-flex justify-content-between align-items-center">
            <!-- 移除顶部的网站 Logo -->
            <!-- <div class="logo">
                <a href="index.php">
                    <img src="<?php echo BASE_URL; ?>images/logo.png" alt="Logo" width="50" height="50">
                </a>
            </div> -->
            <div class="search-bar position-relative">
                <input type="text" id="searchInput" class="form-control" placeholder="搜索职位...">
                <i class="fas fa-search position-absolute top-50 end-0 translate-middle-y me-2" style="cursor: pointer;" onclick="search()"></i>
            </div>
        </header>

        <main>
            <div class="job-detail-container mt-4">
                <h2 class="mb-4"><?php echo htmlspecialchars($job['position']); ?></h2>
                <div class="company-info mb-4">
                    <img src="<?php echo BASE_URL . htmlspecialchars($company['logo']); ?>" alt="<?php echo htmlspecialchars($company['name']); ?> Logo" class="company-logo mb-3" width="150">
                    <p><strong>公司：</strong> <?php echo htmlspecialchars($company['name']); ?></p>
                    <p><strong>地址：</strong> <?php echo htmlspecialchars($company['address']); ?></p>
                </div>
                <div class="job-description mb-4">
                    <h4>职位描述：</h4>
                    <div class="p-3 border rounded-3 bg-light">
                        <p><?php echo nl2br(htmlspecialchars($job['description'])); ?></p>
                    </div>
                </div>
                <div class="job-requirements mb-4">
                    <h4>职位要求：</h4>
                    <div class="p-3 border rounded-3 bg-light">
                        <p><?php echo nl2br(htmlspecialchars($job['requirements'])); ?></p>
                    </div>
                </div>
                <div class="job-salary mb-4">
                    <h4>薪资：</h4>
                    <div class="p-3 border rounded-3 bg-light">
                        <p><?php echo htmlspecialchars($job['salary']); ?></p>
                    </div>
                </div>
            </div>
        </main>

        <footer class="mt-4">
            <div class="contact d-flex justify-content-center align-items-center">
                <a href="https://t.me/manbojt" target="_blank" class="text-decoration-none">
                    <i class="fab fa-telegram fa-lg me-2"></i>
                    <span>联系我们</span>
                </a>
            </div>
        </footer>
    </div>

    <!-- Bootstrap 5 JS Bundle (包含 Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    <!-- 自定义移动端 JS -->
    <script src="../jss/script_mobile_job_detail.js" defer></script>
</body>
</html>