// js/script.js

document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    const jobsContainer = document.getElementById('jobsContainer');
    const jobCards = document.getElementsByClassName('job-card');

    searchInput.addEventListener('input', () => {
        const keyword = searchInput.value.toLowerCase();

        Array.from(jobCards).forEach(card => {
            const position = card.querySelector('h3').textContent.toLowerCase();
            const company = card.querySelector('.job-info dd').textContent.toLowerCase();

            if (position.includes(keyword) || company.includes(keyword)) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    });
});