<?php
// admin/edit_job.php

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// 获取职位信息
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $pdo->prepare("SELECT jobs.id, jobs.position, jobs.description, jobs.requirements, jobs.company_id, companies.name AS company_name FROM jobs JOIN companies ON jobs.company_id = companies.id WHERE jobs.id = ?");
    $stmt->execute([$id]);
    $job = $stmt->fetch();
    if (!$job) {
        header('Location: jobs.php');
        exit();
    }
} else {
    echo "无效的职位ID！";
    exit();
}

$stmt = $pdo->query("SELECT * FROM companies");
$companies = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $company_id = intval($_POST['company_id']);
    $position = trim($_POST['position']);
    $address = trim($_POST['address']);
    $salary = trim($_POST['salary']);
    $description = trim($_POST['description']);
    $requirements = trim($_POST['requirements']);

    // 处理公司Logo上传
    if (isset($_FILES['company_logo']) && $_FILES['company_logo']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $file_name = $_FILES['company_logo']['name'];
        $file_tmp = $_FILES['company_logo']['tmp_name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed)) {
            $new_name = uniqid() . '.' . $file_ext;
            $upload_dir = '../images/company_logos/';
            move_uploaded_file($file_tmp, $upload_dir . $new_name);
            $company_logo = 'images/company_logos/' . $new_name;
        } else {
            echo "不支持的文件类型！";
            exit();
        }
    } else {
        $company_logo = $job['company_logo'];
    }

    $stmt = $pdo->prepare("UPDATE jobs SET company_id = ?, position = ?, address = ?, salary = ?, description = ?, requirements = ?, company_logo = ? WHERE id = ?");
    $stmt->execute([$company_id, $position, $address, $salary, $description, $requirements, $company_logo, $id]);
    header('Location: edit_features.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>编辑职位</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="admin-container">
        <h2>编辑职位</h2>
        <form method="post" enctype="multipart/formform-data">
            <input type="hidden" name="id" value="<?php echo $job['id']; ?>">
            <label for="company_id">公司：</label>
            <select id="company_id" name="company_id" required>
                <?php foreach ($companies as $company): ?>
                    <option value="<?php echo $company['id']; ?>" <?php if ($job['company_id'] == $company['id']) echo 'selected'; ?>><?php echo htmlspecialchars($company['name']); ?></option>
                <?php endforeach; ?>
            </select>
            <label for="position">职位：</label>
            <input type="text" id="position" name="position" value="<?php echo htmlspecialchars($job['position']); ?>" required>
            <label for="address">地址：</label>
            <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($job['address']); ?>" required>
            <label for="salary">薪资：</label>
            <input type="text" id="salary" name="salary" value="<?php echo htmlspecialchars($job['salary']); ?>" required>
            <label for="description">描述：</label>
            <textarea id="description" name="description" rows="4" required><?php echo htmlspecialchars($job['description']); ?></textarea>
            <label for="requirements">要求：</label>
            <textarea id="requirements" name="requirements" rows="4" required><?php echo htmlspecialchars($job['requirements']); ?></textarea>
            <label for="company_logo">公司Logo：</label>
            <input type="file" id="company_logo" name="company_logo">
            <img src="<?php echo htmlspecialchars($job['company_logo']); ?>" alt="公司Logo" style="max-width: 100px; margin-top: 10px;">
            <button type="submit">保存</button>
        </form>
        <a href="edit_features.php">返回编辑功能</a>
    </div>
</body>
</html>