// js/admin_custom_scripts.js

document.addEventListener('DOMContentLoaded', function() {
    // 处理删除按钮点击事件
    document.querySelectorAll('.delete-item').forEach(function(button) {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            var id = this.getAttribute('data-id');
            var type = this.getAttribute('data-type');
            if (confirm('确定要删除这个项目吗？')) {
                var xhr = new XMLHttpRequest();
                xhr.open('GET', 'delete_' + type + '.php?id=' + id, true);
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        var response = JSON.parse(xhr.responseText);
                        if (response.status === 'success') {
                            // 重新加载页面或更新表格
                            window.location.reload();
                        } else {
                            alert('删除失败: ' + response.message);
                        }
                    } else {
                        alert('服务器错误');
                    }
                };
                xhr.send();
            }
        });
    });
});