// js/login.js

document.addEventListener('DOMContentLoaded', function() {
    // 获取登录表单
    const loginForm = document.querySelector('.login-form');

    // 如果表单存在，添加提交事件监听器
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            // 禁用默认提交行为
            e.preventDefault();

            // 获取输入值
            const username = document.querySelector('input[name="username"]').value.trim();
            const password = document.querySelector('input[name="password"]').value.trim();

            // 基本验证
            if (username === '' || password === '') {
                alert('请输入用户名和密码');
                return;
            }

            // 提交表单
            loginForm.submit();
        });
    }

    // 更换验证码图片（如果有验证码的话）
    // const captchaImg = document.querySelector('.login-box img');
    // if (captchaImg) {
    //     captchaImg.addEventListener('click', function() {
    //         this.src = './code.php?r=' + Math.random();
    //     });
    // }
});