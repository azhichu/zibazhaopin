// admin/js/new-script.js

document.addEventListener('DOMContentLoaded', function() {
    // 示例：表单提交事件监听
    const loginForm = document.querySelector('.login-form form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            // 您可以在这里添加表单验证或 AJAX 提交逻辑
            // 例如，阻止默认提交行为，使用 AJAX 发送数据
            // 这里只是一个示例
            // e.preventDefault();
            // ...
        });
    }
});