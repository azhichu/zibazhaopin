<?php
// companies.php

// 引入数据库配置
require_once __DIR__ . '/../config/database.php';

// 获取公司数据
try {
    $stmt = $pdo->query('SELECT * FROM companies ORDER BY created_at DESC');
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // 处理数据库错误
    echo "数据库错误: " . $e->getMessage();
    exit;
}

// 处理成功消息
$success = false;
if (isset($_GET['success']) && $_GET['success'] == 1) {
    $success = true;
}
?>

<?php include 'nav.php'; ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>公司列表</title>
    <!-- 引入 AdminLTE 的 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3/dist/css/adminlte.min.css">
    <!-- 引入 Font Awesome 图标库 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- 引入自定义 CSS -->
    <style>
        /* 自定义样式 */
        .alert-success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }
    </style>
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- 你的导航栏和侧边栏 -->
        <div class="content-wrapper">
            <div class="content">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        公司添加成功！
                    </div>
                <?php endif; ?>
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">公司列表</h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>名称</th>
                                    <th>分类</th>
                                    <th>地址</th>
                                    <th>Logo</th>
                                    <th>创建时间</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($companies as $company): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($company['id']); ?></td>
                                        <td><?php echo htmlspecialchars($company['name']); ?></td>
                                        <td><?php echo htmlspecialchars($company['category_id']); ?></td>
                                        <td><?php echo htmlspecialchars($company['address']); ?></td>
                                        <td>
                                            <?php if ($company['logo']): ?>
                                                <img src="<?php echo htmlspecialchars($company['logo']); ?>" alt="Logo" width="50">
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($company['created_at']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- 引入 AdminLTE 的 JS -->
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3/dist/js/adminlte.min.js"></script>
</body>
</html>