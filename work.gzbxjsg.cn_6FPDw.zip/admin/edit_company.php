<?php
// admin/edit_company.php

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// 获取公司信息
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = ?");
    $stmt->execute([$id]);
    $company = $stmt->fetch();
    if (!$company) {
        header('Location: companies.php');
        exit();
    }
} else {
    echo "无效的公司ID！";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $category_id = intval($_POST['category_id']);
    $address = trim($_POST['address']);

    // 处理公司Logo上传
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $file_name = $_FILES['logo']['name'];
        $file_tmp = $_FILES['logo']['tmp_name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed)) {
            $new_name = uniqid() . '.' . $file_ext;
            $upload_dir = '../images/company_logos/';
            move_uploaded_file($file_tmp, $upload_dir . $new_name);
            $logo = 'images/company_logos/' . $new_name;
        } else {
            echo "不支持的文件类型！";
            exit();
        }
    } else {
        $logo = $company['logo'];
    }

    $stmt = $pdo->prepare("UPDATE companies SET name = ?, category_id = ?, address = ?, logo = ? WHERE id = ?");
    $stmt->execute([$name, $category_id, $address, $logo, $id]);
    header('Location: edit_features.php');
    exit();
}

$stmt = $pdo->query("SELECT * FROM categories");
$categories = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>编辑公司</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="admin-container">
        <h2>编辑公司</h2>
        <form method="post" enctype="multipart/formform-data">
            <input type="hidden" name="id" value="<?php echo $company['id']; ?>">
            <label for="name">公司名称：</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($company['name']); ?>" required>
            <label for="category_id">分类：</label>
            <select id="category_id" name="category_id" required>
                <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category['id']; ?>" <?php if ($company['category_id'] == $category['id']) echo 'selected'; ?>><?php echo htmlspecialchars($category['name']); ?></option>
                <?php endforeach; ?>
            </select>
            <label for="address">地址：</label>
            <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($company['address']); ?>" required>
            <label for="logo">公司Logo：</label>
            <input type="file" id="logo" name="logo">
            <img src="<?php echo htmlspecialchars($company['logo']); ?>" alt="公司Logo" style="max-width: 100px; margin-top: 10px;">
            <button type="submit">保存</button>
        </form>
        <a href="edit_features.php">返回编辑功能</a>
    </div>
</body>
</html>