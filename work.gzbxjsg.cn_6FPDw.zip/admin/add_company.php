<?php
// add_company.php

// 引入数据库配置
require_once __DIR__ . '/../config/database.php';

// 初始化变量
$name = $category_id = $address = '';
$errors = [];

// 获取分类数据
try {
    $stmt = $pdo->prepare('SELECT id, name FROM categories ORDER BY name ASC');
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = '数据库错误: ' . $e->getMessage();
}

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 获取并验证输入数据
    $name = trim($_POST['name']);
    $category_id = trim($_POST['category_id']);
    $address = trim($_POST['address']);
    $logo = $_FILES['logo'] ?? null;

    // 简单的验证
    if (empty($name)) {
        $errors[] = '公司名称不能为空。';
    }
    if (empty($category_id)) {
        $errors[] = '请选择一个分类。';
    }
    if (empty($address)) {
        $errors[] = '地址不能为空。';
    }

    // 如果没有验证错误，则插入数据
    if (empty($errors)) {
        try {
            // 处理 logo 上传
            if ($logo && $logo['error'] === UPLOAD_ERR_OK) {
                // 使用绝对路径
                $uploadDir = '/www/wwwroot/max.gzbxjsg.cn/images/company_logos/';
                $uploadFile = $uploadDir . basename($logo['name']);

                // 检查目录是否存在，如果不存在则创建
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }

                // 移动上传的文件
                if (move_uploaded_file($logo['tmp_name'], $uploadFile)) {
                    // 插入文件路径，使用相对于根目录的路径
                    $logoPath = '/images/company_logos/' . basename($logo['name']);
                } else {
                    $errors[] = '上传 Logo 失败。';
                }
            } else {
                // 如果没有上传 Logo，使用默认值
                $logoPath = 'images/company_logos/default_logo.png';
            }

            // 使用预处理语句插入数据
            $stmt = $pdo->prepare('INSERT INTO companies (name, category_id, address, logo) VALUES (:name, :category_id, :address, :logo)');
            $stmt->execute([
                ':name' => $name,
                ':category_id' => $category_id,
                ':address' => $address,
                ':logo' => $logoPath
            ]);

            // 重定向到成功页面或显示成功消息
            header('Location: companies.php?success=1');
            exit;
        } catch (PDOException $e) {
            $errors[] = '数据库错误: ' . $e->getMessage();
        }
    }
}
?>
<?php include 'nav.php'; ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>添加公司</title>
    <!-- 引入 AdminLTE 的 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3/dist/css/adminlte.min.css">
    <!-- 引入 Font Awesome 图标库 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- 引入自定义 CSS -->
    <style>
        /* 自定义粉色主题 */
        body {
            background-color: #f8f9fa;
        }
        .card {
            background-color: #fff;
            border: 1px solid #e6e6fa;
            box-shadow: 0 0 15px rgba(100, 100, 200, 0.1);
            border-radius: 10px;
        }
        .card-header {
            background-color: #f3e5f5;
            border-bottom: 1px solid #e6e6fa;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }
        .form-control {
            border-radius: 25px;
            border: 1px solid #ccc;
            padding: 10px 20px;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #9c27b0;
            box-shadow: 0 0 0 0.2rem rgba(156, 39, 176, 0.25);
        }
        .btn-primary {
            background-color: #9c27b0;
            border-color: #9c27b0;
            border-radius: 25px;
            padding: 10px 25px;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #7b1fa2;
            border-color: #7b1fa2;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(156, 39, 176, 0.3);
        }
        /* 表单输入框动画 */
        .form-group input, .form-group select {
            position: relative;
        }
        .form-group input:focus, .form-group select:focus {
            animation: glow 1s infinite alternate;
        }
        @keyframes glow {
            from {
                border-color: #9c27b0;
            }
            to {
                border-color: #e1bee7;
            }
        }
        /* 按钮加载动画 */
        .btn-loading::after {
            content: '';
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            width: 16px;
            height: 16px;
            border: 2px solid #fff;
            border-top-color: transparent;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            from {
                transform: translateY(-50%) rotate(0deg);
            }
            to {
                transform:: translateY(-50()) rotate(360deg);
            }
        }
    </style>
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- 你的导航栏和侧边栏 -->
        <!-- 这里假设 nav.php 和 sidebar.php 已经包含必要的 HTML 结构 -->
        <div class="content-wrapper">
            <div class="content">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">添加公司</h3>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php foreach ($errors as $error): ?>
                                        <li><?php echo htmlspecialchars($error); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form method="post" enctype="multipart/form-data" id="addCompanyForm">
                            <div class="form-group">
                                <label for="name">公司名称：</label>
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="category_id">分类：</label>
                                <select class="form-control" id="category_id" name="category_id" required>
                                    <option value="">请选择分类</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>" <?php echo ($category_id == $category['id']) ? 'selected' : ''; ?>> <?php echo htmlspecialchars($category['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="address">地址：</label>
                                <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($address); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="logo">公司Logo：</label>
                                <input type="file" class="form-control-file" id="logo" name="logo">
                            </div>
                            <button type="submit" class="btn btn-primary" id="submitBtn">添加</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- 引入 AdminLTE 的 JS -->
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3/dist/js/adminlte.min.js"></script>
    <!-- 引入自定义 JS -->
    <script>
        // 表单提交脚本
        document.getElementById('addCompanyForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 提交中...';
            submitBtn.disabled = true;
            submitBtn.classList.add('btn-loading');

            // 提交表单
            this.submit();
        });
    </script>
</body>
</html>