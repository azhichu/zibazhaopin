<?php
// jobs.php

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// 处理添加职位
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_job'])) {
    $company_id = intval($_POST['company_id']);
    $position = trim($_POST['position']);
    $address = trim($_POST['address']);
    $salary = trim($_POST['salary']);
    $description = trim($_POST['description']);
    $requirements = trim($_POST['requirements']);

    // 处理公司Logo上传
    if (isset($_FILES['company_logo']) && $_FILES['company_logo']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $file_name = $_FILES['company_logo']['name'];
        $file_tmp = $_FILES['company_logo']['tmp_name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed)) {
            $new_name = uniqid() . '.' . $file_ext;
            $upload_dir = '../images/company_logos/';
            move_uploaded_file($file_tmp, $upload_dir . $new_name);
            $company_logo = 'images/company_logos/' . $new_name;
        } else {
            echo "不支持的文件类型！";
            exit();
        }
    } else {
        $company_logo = 'images/company_logos/default_logo.png';
    }

    $stmt = $pdo->prepare("INSERT INTO jobs (company_id, position, address, salary, description, requirements, company_logo) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$company_id, $position, $address, $salary, $description, $requirements, $company_logo]);
    header('Location: jobs.php');
    exit();
}

// 获取所有公司
$stmt = $pdo->query("SELECT id, name FROM companies");
$companies = $stmt->fetchAll();

// 获取所有职位
$stmt = $pdo->query("SELECT jobs.id, jobs.position, jobs.address, jobs.salary, jobs.description, jobs.requirements, jobs.company_logo, companies.name AS company_name FROM jobs JOIN companies ON jobs.company_id = companies.id");
$jobs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>职位管理</title>
    <!-- 引入 Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- 引入 Bootstrap Icons 图标库 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- 自定义 CSS -->
    <style>
        body {
            background-color: #e9ecef;
        }
        .admin-container {
            padding: 20px;
        }
        .card {
            background-color: #ffffff;
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #0d6efd;
            color: #ffffff;
            border-radius: 10px 10px 0 0;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0b5ed7;
        }
        .btn-warning {
            background-color: #ffc107;
            border-color: #ffc107;
        }
        .btn-warning:hover {
            background-color: #e0a800;
            border-color: #e0a800;
        }
        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
            border-color: #c82333;
        }
        .footer {
            text-align: center;
            padding: 20px;
            background-color: #ffffff;
            border-top: 1px solid #dee2e6;
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- 导航栏开始 -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php"><i class="bi bi-speedometer2"></i> 后台管理</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="切换导航">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">首页</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="companies.php">公司管理</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="jobs.php">职位管理</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="categories.php">分类管理</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="edit_features.php">编辑功能</a>
                        </li>
                        <!-- 添加更多导航链接 -->
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="bi bi-person"></i> 用户</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#"><i class="bi bi-box-arrow-right"></i> 登出</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- 导航栏结束 -->

        <div class="content">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h2>添加新职位</h2>
                </div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="company_id" class="form-label">公司：</label>
                            <select id="company_id" name="company_id" class="form-select" required>
                                <?php foreach ($companies as $company): ?>
                                    <option value="<?php echo $company['id']; ?>"><?php echo htmlspecialchars($company['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="position" class="form-label">职位名称：</label>
                            <input type="text" id="position" name="position" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="address" class="form-label">工作地点：</label>
                            <input type="text" id="address" name="address" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="salary" class="form-label">薪资范围：</label>
                            <input type="text" id="salary" name="salary" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">职位描述：</label>
                            <textarea id="description" name="description" class="form-control" rows="4" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="requirements" class="form-label">职位要求：</label>
                            <textarea id="requirements" name="requirements" class="form-control" rows="4" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="company_logo" class="form-label">公司Logo：</label>
                            <input type="file" id="company_logo" name="company_logo" class="form-control">
                        </div>
                        <button type="submit" name="add_job" class="btn btn-primary"><i class="bi bi-plus-circle"></i> 添加职位</button>
                    </form>
                </div>
            </div>

            <div class="card mt-4">
                <div class="card-header bg-primary text-white">
                    <h2>职位列表</h2>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>职位名称</th>
                                <th>公司</th>
                                <th>工作地点</th>
                                <th>薪资范围</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($jobs as $job): ?>
                                <tr>
                                    <td><?php echo $job['id']; ?></td>
                                    <td><?php echo htmlspecialchars($job['position']); ?></td>
                                    <td><?php echo htmlspecialchars($job['company_name']); ?></td>
                                    <td><?php echo htmlspecialchars($job['address']); ?></td>
                                    <td><?php echo htmlspecialchars($job['salary']); ?></td>
                                    <td>
                                        <a href="edit_job.php?id=<?php echo $job['id']; ?>" class="btn btn-sm btn-warning"><i class="bi bi-pencil-square"></i> 编辑</a>
                                        <a href="delete_job.php?id=<?php echo $job['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定要删除这个职位吗？');"><i class="bi bi-trash"></i> 删除</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <footer class="footer">
            <p>&copy; <?php echo date("Y"); ?> 您的公司后台管理</p>
        </footer>
    </div>
    <!-- 引入 Bootstrap 5 JS 和依赖项 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- 自定义 JS -->
    <script>
        // 可根据需要添加自定义 JS 代码
    </script>
</body>
</html>