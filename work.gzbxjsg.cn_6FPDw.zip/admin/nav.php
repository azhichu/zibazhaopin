<?php
// admin/nav.php

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}
?>
<!-- 导航栏开始 -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php"><i class="bi bi-speedometer2"></i> 后台管理</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="切换导航">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php">首页</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        公司管理
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="companies.php">公司列表</a></li>
                        <li><a class="dropdown-item" href="add_company.php">添加公司</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="jobs.php">职位管理</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="categories.php">分类管理</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="edit_features.php">编辑功能</a>
                </li>
                <!-- 添加更多导航链接 -->
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="#" style="color: black;"><i class="bi bi-person"></i> 用户</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php" style="color: black;"><i class="bi bi-box-arrow-right"></i> 登出</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!-- 导航栏结束 -->

<!-- 引入 Bootstrap 5 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- 引入 Bootstrap Icons 图标库 -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<!-- 引入自定义 CSS -->
<link rel="stylesheet" href="css/admin_custom_styles_v2.css">
<!-- 引入 Font Awesome JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.js"></script>
<!-- 引入自定义 JS -->
<script src="js/admin_custom_scripts.js" defer></script>