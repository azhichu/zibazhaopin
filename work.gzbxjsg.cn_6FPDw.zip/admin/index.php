<?php
// admin/index.php

session_start();

// 检查用户是否已登录
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

require_once __DIR__ . '/../config/database.php';

// 获取统计数据数据
try {
    $stmt = $pdo->query("SELECT COUNT(*) AS total_companies FROM companies");
    $total_companies = $stmt->fetch()['total_companies'];

    $stmt = $pdo->query("SELECT COUNT(*) AS total_jobs FROM jobs");
    $total_jobs = $stmt->fetch()['total_jobs'];

    $stmt = $pdo->query("SELECT COUNT(*) AS total_categories FROM categories");
    $total_categories = $stmt->fetch()['total_categories'];
} catch (PDOException $e) {
    // 处理数据库错误
    echo "数据库错误: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>孜巴招募后台管理首页</title>
    <!-- 引入 Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- 引入 Bootstrap Icons 图标库 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- 引入自定义 CSS -->
    <link rel="stylesheet" href="css/admin_custom_styles_v2.css">
</head>
<body>
    <?php include 'nav.php'; ?>
    <div class="container-fluid bg-primary text-white py-4">
        <div class="container">
            <h1>欢迎登录后台</h1>
            <p>您已成功登录到后台管理系统。</p>
        </div>
    </div>
    <div class="container my-4">
        <div class="row">
            <!-- 公司总数卡片 -->
            <div class="col-md-4">
                <div class="card bg-info text-white mb-4">
                    <div class="card-body">
                        <h5 class="card-title">公司总数</h5>
                        <p class="card-text"><?php echo $total_companies; ?></p>
                    </div>
                </div>
            </div>
            <!-- 职位总数卡片 -->
            <div class="col-md-4">
                <div class="card bg-info text-white mb-4">
                    <div class="card-body">
                        <h5 class="card-title">职位总数</h5>
                        <p class="card-text"><?php echo $total_jobs; ?></p>
                    </div>
                </div>
            </div>
            <!-- 分类总数卡片 -->
            <div class="col-md-4">
                <div class="card bg-info text-white mb-4">
                    <div class="card-body">
                        <h5 class="card-title">分类总数</h5>
                        <p class="card-text"><?php echo $total_categories; ?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h2>快速链接</h2>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"><a href="add_company.php" class="text-decoration-none">添加新公司</a></li>
                            <li class="list-group-item"><a href="add_job.php" class="text-decoration-none">添加新职位</a></li>
                            <li class="list-group-item"><a href="edit_features.php" class="text-decoration-none">管理新功能</a></li>
                            <li class="list-group-item"><a href="companies.php" class="text-decoration-none">查看所有公司</a></li>
                            <li class="list-group-item"><a href="jobs.php" class="text-decoration-none">查看所有职位</a></li>
                            <li class="list-group-item"><a href="categories.php" class="text-decoration-none">查看所有分类</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-12">
                <a href="logout.php" class="btn btn-danger"><i class="bi bi-box-arrow-right"></i> 退出登录</a>
            </div>
        </div>
    </div>
    <!-- 引入 Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- 引入 Bootstrap Icons JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.js"></script>
    <!-- 引入自定义 JS -->
    <script src="js/admin_custom_scripts.js"></script>
</body>
</html>