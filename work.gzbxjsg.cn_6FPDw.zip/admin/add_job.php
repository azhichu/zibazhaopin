<?php
// admin/add_job.php

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $company_id = intval($_POST['company_id']);
    $position = trim($_POST['position']);
    $address = trim($_POST['address']);
    $salary = trim($_POST['salary']);
    $description = trim($_POST['description']);
    $requirements = trim($_POST['requirements']);

    // 处理公司Logo上传
    if (isset($_FILES['company_logo']) && $_FILES['company_logo']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $file_name = $_FILES['company_logo']['name'];
        $file_tmp = $_FILES['company_logo']['tmp_name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed)) {
            $new_name = uniqid() . '.' . $file_ext;
            $upload_dir = '../images/company_logos/';
            move_uploaded_file($file_tmp, $upload_dir . $new_name);
            $company_logo = 'images/company_logos/' . $new_name;
        } else {
            echo "不支持的文件类型！";
            exit();
        }
    } else {
        $stmt = $pdo->prepare("SELECT logo FROM companies WHERE id = ?");
        $stmt->execute([$company_id]);
        $company = $stmt->fetch();
        $company_logo = $company['logo'];
    }

    $stmt = $pdo->prepare("INSERT INTO jobs (company_id, position, address, salary, description, requirements, company_logo) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$company_id, $position, $address, $salary, $description, $requirements, $company_logo]);
    header('Location: jobs.php');
    exit();
}

$stmt = $pdo->query("SELECT * FROM companies");
$companies = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>添加职位</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="admin-container">
        <h2>添加职位</h2>
        <form method="post" enctype="multipart/formform-data">
            <label for="company_id">公司：</label>
            <select id="company_id" name="company_id" required>
                <?php foreach ($companies as $company): ?>
                    <option value="<?php echo $company['id']; ?>"><?php echo htmlspecialchars($company['name']); ?></option>
                <?php endforeach; ?>
            </select>
            <label for="position">职位：</label>
            <input type="text" id="position" name="position" required>
            <label for="address">地址：</label>
            <input type="text" id="address" name="address" required>
            <label for="salary">薪资：</label>
            <input type="text" id="salary" name="salary" required>
            <label for="description">描述：</label>
            <textarea id="description" name="description" rows="4" required></textarea>
            <label for="requirements">要求：</label>
            <textarea id="requirements" name="requirements" rows="4" required></textarea>
            <label for="company_logo">公司Logo：</label>
            <input type="file" id="company_logo" name="company_logo">
            <button type="submit">添加</button>
        </form>
        <a href="jobs.php">返回职位管理</a>
    </div>
</body>
</html>