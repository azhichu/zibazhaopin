<?php
// login.php

session_start();

// 包含数据库配置
require_once __DIR__ . '/../config/database.php';

// 初始化变量
$error = '';

// 检查表单是否提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 获取并清理用户输入
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // 验证输入是否为空
    if (empty($username) || empty($password)) {
        $error = "用户名和密码不能为空。";
    } else {
        try {
            // 使用 PDO 准备 SQL 语句，防止 SQL 注入
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
            $stmt->execute(['username' => $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // 直接比较密码
                if ($password === $user['password']) {
                    // 设置会话变量以标识管理员已登录
                    $_SESSION['admin_logged_in'] = true;
                    $_SESSION['username'] = $user['username'];
                    
                    // 可选：设置会话过期时间
                    // $_SESSION['LAST_ACTIVITY'] = time();

                    // 重定向到仪表板或其他受保护的页面
                    header("Location: dashboard.php");
                    exit();
                } else {
                    $error = "用户名或密码不正确。";
                }
            } else {
                $error = "用户名或密码不正确。";
            }
        } catch (PDOException $e) {
            // 处理数据库错误
            $error = "数据库错误：" . $e->getMessage();
            // 在生产环境中，避免显示详细错误信息
            // $error = "发生错误，请稍后再试。";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>登录</title>
    <!-- 引入 Bootstrap CSS 通过 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* 自定义样式 */
        .login-container {
            max-width: 400px;
            margin: 100px auto;
        }
        .login-card {
            padding: 30px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .login-card h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <h2>管理员登录</h2>
            <?php if (!empty($error)) { echo "<p class='error'>{$error}</p>"; } ?>
            <form method="POST" action="login.php">
                <div class="mb-3">
                    <label for="username" class="form-label">用户名</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">密码</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">登录</button>
            </form>
        </div>
    </div>

    <!-- 引入 Bootstrap JS 和依赖的 Popper.js 通过 CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>