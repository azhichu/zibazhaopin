<?php
// admin/edit_features.php

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

// 获取公司列表
$stmt = $pdo->query("SELECT * FROM companies");
$companies = $stmt->fetchAll();

// 获取职位列表
$stmt = $pdo->query("SELECT jobs.id, jobs.position, companies.name AS company_name FROM jobs JOIN companies ON jobs.company_id = companies.id");
$jobs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>编辑功能</title>
    <!-- 引入 Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- 引入 Bootstrap Icons 图标库 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- 引入自定义 CSS -->
    <link rel="stylesheet" href="css/admin_custom_styles.css">
    <!-- 引入 Font Awesome JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.js"></script>
    <!-- 引入自定义 JS -->
    <script src="js/admin_custom_scripts.js" defer></script>
</head>
<body>
    <?php include 'nav.php'; ?>
    <div class="admin-container">
        <div class="content">
            <!-- 标题和返回链接 -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>编辑功能</h1>
                <a href="index.php" class="btn btn-secondary"><i class="bi bi-arrow-left-circle"></i> 返回首页</a>
            </div>

            <!-- 编辑公司列表 -->
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h2>编辑公司</h2>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>名称</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($companies as $company): ?>
                                <tr>
                                    <td><?php echo $company['id']; ?></td>
                                    <td><?php echo htmlspecialchars($company['name']); ?></td>
                                    <td>
                                        <a href="edit_company.php?id=<?php echo $company['id']; ?>" class="btn btn-sm btn-primary"><i class="bi bi-pencil-square"></i> 编辑</a>
                                        <a href="delete_company.php?id=<?php echo $company['id']; ?>" class="btn btn-sm btn-danger delete-item" data-id="<?php echo $company['id']; ?>" data-type="company"><i class="bi bi-trash"></i> 删除</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- 编辑职位列表 -->
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h2>编辑职位</h2>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>职位</th>
                                <th>公司</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($jobs as $job): ?>
                                <tr>
                                    <td><?php echo $job['id']; ?></td>
                                    <td><?php echo htmlspecialchars($job['position']); ?></td>
                                    <td><?php echo htmlspecialchars($job['company_name']); ?></td>
                                    <td>
                                        <a href="edit_job.php?id=<?php echo $job['id']; ?>" class="btn btn-sm btn-primary"><i class="bi bi-pencil-square"></i> 编辑</a>
                                        <a href="delete_job.php?id=<?php echo $job['id']; ?>" class="btn btn-sm btn-danger delete-item" data-id="<?php echo $job['id']; ?>" data-type="job"><i class="bi bi-trash"></i> 删除</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <footer class="footer">
            <p>&copy; <?php echo date("Y"); ?> 您的公司后台管理</p>
        </footer>
    </div>
</body>
</html>