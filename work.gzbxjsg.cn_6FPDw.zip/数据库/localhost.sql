<b>Notice</b>: failed to open file: streams.php<b>Notice</b>: failed to open file: gettext.php-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2025-06-22 20:43:31
-- 服务器版本： 5.7.44-log
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zhaopi`
--

-- --------------------------------------------------------

--
-- 表的结构 `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES
(4, '迪拜', '迪拜地区，豪华，博彩，程序开发等', '2025-06-22 09:17:43'),
(5, '柬埔寨', '柬埔寨地区', '2025-06-22 09:19:18'),
(6, '老挝', '老挝地区', '2025-06-22 09:19:33'),
(7, '缅甸', '缅甸地区', '2025-06-22 09:19:45'),
(8, '泰国', '泰国地区', '2025-06-22 09:19:56'),
(9, '斯里兰卡', '斯里兰卡地区', '2025-06-22 10:14:38');

-- --------------------------------------------------------

--
-- 表的结构 `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `logo` varchar(255) DEFAULT 'images/company_logos/default_logo.png',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `category_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `companies`
--

INSERT INTO `companies` (`id`, `name`, `address`, `logo`, `created_at`, `category_id`) VALUES
(9, '迪拜综合媒体', '迪拜地区', '/images/company_logos/IMG_20250622_181841.jpg', '2025-06-22 10:20:24', 4);

-- --------------------------------------------------------

--
-- 表的结构 `jobs`
--

CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int(10) unsigned NOT NULL,
  `company` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `salary` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `requirements` text NOT NULL,
  `company_logo` varchar(255) DEFAULT 'images/company_logos/default_logo.png',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `company_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `jobs`
--

INSERT INTO `jobs` (`id`, `company`, `position`, `address`, `salary`, `description`, `requirements`, `company_logo`, `created_at`, `company_id`) VALUES
(10, '', '招商专员', '迪拜', '10k转12k+提成-3-6个点  前2个月提成5个点 试用期：2个月', '工作时间：10休4  （12:00-22:00）\r\n国籍：不限\r\n岗位职责     \r\n1.利用各种平台、渠道和工具进行网络推广，获取潜在客户； \r\n2. 搜集并分析推广反馈数据，不断调整优化推广方法；\r\n3. 收集同行的推广信息进行对比，提成改善或调整方案；\r\n4. 完成上级下达的各项任务。\r\n优势，\r\n新盘口会涌进很多新会员，公司扶持资源费新人渠道费5000-10000，转正后10000-30000渠道费，\r\n提成点位，线下所有代理线下会员负盈利5个点位提成，月入10w不是梦。', '会中文', 'images/company_logos/default_logo.png', '2025-06-22 10:22:31', 9),
(11, '', '招聘组长', '迪拜', '薪酬待遇 15000-20000', '国籍 优先中国籍/外籍优秀者面议\r\n性别：男女不限\r\n年龄：40岁以下\r\n工作时间：9休4 \r\n岗位要求\r\n1较强的综合分析能力、沟通协调能力、组织规划能力;\r\n2. 能承受较强的工作压力;\r\n3. 办事思路缜密、细心，具有较强的责任心，富有亲和力；\r\n4. 能熟练使用电脑及各种办公软件，具备基本的网络知识；\r\n5. 有招聘工作经验优先。', '1。负责完成月度/季度/年度的招聘任务及目标达成\r\n2.制定和执行招聘计划、开展有效招聘工作，并保证招聘渠道的有效性\r\n3.对候选人进行初步筛选后安排面试并进行入职跟踪服务\r\n4.根据公司的业务发展需求，定期发布招聘信息\r\n5.配合上级安排的其他临时性事务', 'images/company_logos/default_logo.png', '2025-06-22 10:27:05', 9);

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`, `created_at`) VALUES
(1, 'admin', '123456', 'admin@example.com', 'admin', '2025-06-21 08:18:46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- 限制导出的表
--

--
-- 限制表 `companies`
--
ALTER TABLE `companies`
  ADD CONSTRAINT `companies_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- 限制表 `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
